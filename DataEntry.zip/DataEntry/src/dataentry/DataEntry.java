/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataentry;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.event.*; 
import javax.swing.table.*;
import javax.swing.border.*;


public class DataEntry implements ActionListener,ListSelectionListener{
    JFrame f;
    JMenuBar mb;    
    JMenu file,edit,view; 
    JTextField name_field, address_field;
    ButtonGroup bg;
    JComboBox cb;
    JButton add, clear,update,delete;
    DefaultTableModel model; 
    JTable jt;
    JPanel panel1 ,panel2, panel;
    JRadioButton r1, r2,r3;

public DataEntry(){
    f = new JFrame("Data Entry for COVID19");
}

public static void main(String[] args) {  
   
    new DataEntry().createGUI();
}         

//top menu and menuitem
public void createGUI(){
  
   

mb=new JMenuBar();    
file=new JMenu("File");    
edit=new JMenu("Edit");    
view=new JMenu("View");   

mb.add(file);
mb.add(edit);
mb.add(view);  
f.add(mb);
f.setJMenuBar(mb);
//adding the panel 

panel2 = new JPanel();      
panel2.setLayout(null);  

JLabel name = new JLabel("Name");
name.setBounds(50,200,50,30);
name_field = new JTextField();
name_field.setBounds(120,200,250,30);

JLabel address = new JLabel("Address");
address.setBounds(50,250,50,30);
address_field = new JTextField();
address_field.setBounds(120,250,250,30);


JLabel gender = new JLabel("Gender");
gender.setBounds(50,290,50,30);

r1=new JRadioButton("Male"); 
r1.setBounds(120,290,60,30);   
r2=new JRadioButton("Female"); 
r2.setBounds(200,290,70,30);   
r3=new JRadioButton("Unspecified"); 
r3.setBounds(280,290,120,30);

bg=new ButtonGroup();    
bg.add(r1);bg.add(r2); bg.add(r3);    

JLabel positive = new JLabel("POSITIVE");
positive.setBounds(50,330,60,30);
String arr[] = {"Yes","No"};
cb= new JComboBox(arr); 
cb.setBounds(120,330,250,30);   


panel2.add(name);
panel2.add(name_field);
panel2.add(address);
panel2.add(address_field);
panel2.add(gender);    
panel2.add(r1);  
panel2.add(r2);
panel2.add(r3);
panel2.add(positive);
panel2.add(cb);

// JTable

model = new DefaultTableModel();

jt=new JTable(model);    
model.addColumn("ID");
model.addColumn("NAME");
model.addColumn("ADDRESS");
model.addColumn("GENDER");
model.addColumn("COVID19");
//model.addActionListener(this);
// add model listener
listener();
//jt.setCellSelectionEnabled(true);  
JScrollPane sp=new JScrollPane(jt);    



panel=new JPanel();  
panel1 = new JPanel();
panel2.setBorder(new TitledBorder(new LineBorder(Color.black, 1, true), "List of Data"));
sp.setBorder(new TitledBorder(new LineBorder(Color.black, 1, true), "Data Entry")); 

GridLayout layout = new GridLayout(0,2);
panel1.setLayout(layout);
panel.setLayout(null);
panel1.add(panel2);
panel1.add(sp);
panel1.setBounds(10,10,900,550);

panel.add(panel1);

// creating a row with 4 buttons 

GridLayout lay = new GridLayout(1,4);
JPanel btns = new JPanel();

btns.setLayout(lay);
btns.setBounds(10,580,900,60);
btns.setBorder(new TitledBorder(new LineBorder(Color.black, 1, true), "Actions")); 

add = new JButton("SAVE");
add.addActionListener(this);

update = new JButton("UPDATE");
update.addActionListener(this);

delete = new JButton("DELETE");
delete.addActionListener(this);

clear = new JButton("CLEAR");
clear.addActionListener(this);

btns.add(add);
btns.add(update);
btns.add(delete);
btns.add(clear);
panel.add(btns);

f.add(panel);
f.setSize(950,700);
f.setVisible(true);
f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

}  


@Override
public void actionPerformed(ActionEvent e){  

    String command = e.getActionCommand();  
         
         if( command.equals( "SAVE" ))  {
//            function to add to jtable and database
            insertData();
            clearform();

         } else if( command.equals( "UPDATE" ) )  {

//        Now we have added the data in form
          updateform();


         } else if( command.equals( "DELETE" ) )  {
            if(deleterow()) {   
            clearform();
            }

         }else if( command.equals( "CLEAR" ) ) {
         clearform();

         }  
        else {   }
}
  

public void insertData(){
            String name_to_fill = name_field.getText();
            String address_to_fill = address_field.getText();

            String gender_to_fill;
            if(r1.isSelected()){gender_to_fill = "Male";}
            else if(r2.isSelected()){gender_to_fill = "Female";}
            else{gender_to_fill = "Unspecified";}

           int index = model.getRowCount()+1;
            Object[] row = {index,name_to_fill, address_to_fill, gender_to_fill,cb.getSelectedItem().toString()};
            try{
            model.addRow(row);
            } catch(Exception w){
            System.out.println(w.getMessage());
            }
}

public void updateform(){
 int selected = jt.getSelectedRow();
        model.setValueAt("1", selected, 0);
        model.setValueAt(name_field.getText(), selected, 1);
        model.setValueAt(address_field.getText(), selected, 2);

         String gender_to_fill;
            if(r1.isSelected()){gender_to_fill = "Male";}
            else if(r2.isSelected()){gender_to_fill = "Female";}
            else{gender_to_fill = "Unspecified";}
        model.setValueAt(gender_to_fill, selected, 3);
        model.setValueAt(cb.getSelectedItem().toString(), selected, 4);
        clearform();
    }

public void clearform(){

//  clearing the form
    name_field.setText("");
    address_field.setText("");
    r1.setSelected(false);
    r2.setSelected(false);
    r3.setSelected(false);
    cb.setSelectedIndex(0);
}



// adding the method to delete the  row
public boolean deleterow(){
        int row =  jt.getSelectedRow();
        System.out.println("the selected row is "+ row);
        if(row!=-1){
                    model.removeRow(row);
                    return true;
                    }
      
           return false;           
}



@SuppressWarnings("unchecked")
public void listener(){
    try{
        ListSelectionModel select= jt.getSelectionModel();  
//            select.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        select.addListSelectionListener(new ListSelectionListener(){
        public void valueChanged(ListSelectionEvent e){
    
            int row = jt.getSelectedRow();
            row = jt.convertRowIndexToModel(row);
            String name = (String) model.getValueAt(row, 1);  
            String Address = (String) model.getValueAt(row, 2);  
            String gender = (String )model.getValueAt(row,3);  
            String posi = (String) model.getValueAt(row,4);

            name_field.setText(name);
            address_field.setText(Address);
            if(gender=="Male"){
                r1.setSelected(true);
            }else if(gender=="Female"){
                r2.setSelected(true);
            }else{
                r3.setSelected(true);
            }
             
            if (posi=="YES"){
                cb.setSelectedIndex(0);
            }else{
                cb.setSelectedIndex(1);
            }
            return;
            }
        });
    }catch(Exception e){
            System.out.println(e.getMessage());
    }
    }
}  
